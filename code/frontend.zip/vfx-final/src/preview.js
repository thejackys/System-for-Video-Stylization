import React from 'react';
import Box from '@mui/material/Box';
import Slider from "react-slick";

import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import "./slick-custom.css"

function Preview(props) {
  const settings = {
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1
  };

  const imageStyle = {
    'maxHeight': '100%',
    'maxWidth': '100%'
  }

  return (
    <Box>
      <Slider {...settings}>
        {
          props.previewImages.map((imagePath) =>
            <div>
              <img style={imageStyle} src={"/" + imagePath} />
            </div>
          )
        }
      </Slider>
    </Box>
  );
}

export default Preview;
