import React from 'react';
import VideoJS from "./VideoJS.js";
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Container from '@mui/material/Container';
import ButtonBase from '@mui/material/ButtonBase';
import Slider from "react-slick";
import "slick-carousel/slick/slick.css"; 
import "slick-carousel/slick/slick-theme.css";
import "./slick-custom.css"

function Result(props) {
  const videoRef = React.useRef(null);

  const videoJsOptions = {
    autoplay: 'muted',
    controls: true,
    responsive: true,
    fluid: true,
    sources: [{
      src: props.videoSrc,
      type: 'video/mp4'
    }]
  };
  
  const sliderSettings = {
    dots: false,
    infinite: true,
    speed: 500,
    slidesToShow: 4,
    slidesToScroll: 1
  };

  return (
    <div>
    <VideoJS options={videoJsOptions} videoRef={videoRef} />
    </div>
  );
}

export default Result;
