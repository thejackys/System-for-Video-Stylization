import React from 'react';
import VideoJS from "./VideoJS.js";
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Container from '@mui/material/Container';
import ButtonBase from '@mui/material/ButtonBase';
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import "./slick-custom.css"

// reference: https://stackoverflow.com/a/35859991
function captureVideo(video) {
  var canvas = document.createElement("canvas");
  canvas.width = video.videoWidth;
  canvas.height = video.videoHeight;
  var canvasContext = canvas.getContext("2d");
  canvasContext.drawImage(video, 0, 0);
  return canvas.toDataURL('image/png');
}

function FrameSelector(props) {
  const videoRef = React.useRef(null);

  const videoJsOptions = {
    autoplay: 'muted',
    controls: true,
    responsive: true,
    fluid: true,
    sources: [{
      src: `/static/videos/video.mp4?${Date.now()}'`, // cache busting
      type: 'video/mp4'
    }]
  };

  const sliderSettings = {
    dots: false,
    infinite: true,
    speed: 500,
    slidesToShow: 4,
    slidesToScroll: 1
  };

  const imageStyle = {
    'maxHeight': '100%',
    'maxWidth': '100%'
  }

  function computeFrameNumber(videoElement) {
    return Math.floor((videoElement.currentTime * 29.97))
  }

  function addFrame() {
    const videoElement = videoRef.current;
    let fn = computeFrameNumber(videoElement);
    let img = captureVideo(videoElement);
    let isFrameNumberExist = props.selectedFrames.filter((frameInfo) => frameInfo.fn === fn).length != 0;
    if (isFrameNumberExist) return;
    props.setSelectedFrames([
      ...props.selectedFrames,
      {
        fn: fn,
        img: img
      }
    ]);
    console.log(props.selectedFrames);
  }

  function createPaddingDiv() {
    let pad = [];
    for (let i = props.selectedFrames.length; i < 4; i++) {
      pad.push(null);
    }
    return pad;
  }

  function deleteSelectedFrame(event) {
    props.setSelectedFrames(props.selectedFrames.filter((frameInfo) => frameInfo.fn != event.target.alt));
  }

  return (
    <div>
      <VideoJS options={videoJsOptions} videoRef={videoRef} />
      <Box textAlign='center' sx={{ pt: 5, pb: 5 }}>
        <Button variant="contained" onClick={addFrame}>Add Frame</Button>
      </Box>
      <Slider {...sliderSettings}>
        {
          props.selectedFrames.map((selectedFrame) =>
            <div>
              <ButtonBase
                value={selectedFrame.fn}
                onClick={deleteSelectedFrame}
              >
                <img alt={selectedFrame.fn} style={imageStyle} src={selectedFrame.img} />
              </ButtonBase>
            </div>
          )
        }
        {
          createPaddingDiv().map(() =>
            <div>
            </div>
          )
        }
      </Slider>
    </div>
  );
}

export default FrameSelector;
