import * as React from 'react';
import {
  Routes,
  Route,
} from "react-router-dom";
import Container from '@mui/material/Container';
import Stack from '@mui/material/Stack';
import Paper from '@mui/material/Paper';
import Typography from '@mui/material/Typography';
import Stepper from '@mui/material/Stepper';
import Step from '@mui/material/Step';
import StepLabel from '@mui/material/StepLabel';
import Button from '@mui/material/Button';
import Box from '@mui/material/Box';
import CircularProgress from '@mui/material/CircularProgress';

import FrameSelector from "./frameSelector.js";
import ParamForm from "./paramForm.js";
import Preview from "./preview.js";
import Result from "./result.js";
import CircularProgressWithLabel from './CircularProgressWithLabel.js';

const steps = ['Select Frames', 'Adjust Model', 'Preview', 'Finish'];

// https://stackoverflow.com/questions/951021/what-is-the-javascript-version-of-sleep
function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

function App() {
  const [activeStep, setActiveStep] = React.useState(0);
  const [selectedFrames, setSelectedFrames] = React.useState([]);
  const [modelParam, setModelParam] = React.useState({
    model: "FST",
    style: "udnie"
  });
  const [files, setFiles] = React.useState([]);
  // status
  // 0 -> normal, 1 -> loading without progress, 2 -> loading with progress
  const [status, setStatus] = React.useState(0); 
  const [loadingProgress, setLoadingProgress] = React.useState();
//  const [loadingTimer, setLoadingTimer] = React.useState();
  const [previewImages, setPreviewImages] = React.useState([]);
  const [resultVideo, setResultVideo] = React.useState();
  let loadingTimer = 0;
//  let host = "http://140.112.91.220";
//  let port = 12112;

  function getFramelist() {
    let frames = "";
    selectedFrames.forEach((selectedFrame) => {
      frames += selectedFrame.fn + ","
    });
    return frames.slice(0, -1);
  }

  function getStepContent(step) {
    if (status == 1) {
      return (
        <Stack alignItems="center">
          <CircularProgress />
        </Stack>
      );
    }
    else if (status == 2) {
      return (
        <Stack alignItems="center">
          <CircularProgressWithLabel value={loadingProgress}/>
        </Stack>
      );
    }

    switch (step) {
      case 0:
        return <FrameSelector selectedFrames={selectedFrames} setSelectedFrames={setSelectedFrames} />
      case 1:
        return <ParamForm modelParam={modelParam} setModelParam={setModelParam} files={files} setFiles={setFiles} />
      case 2:
        return <Preview previewImages={previewImages} />;
      case 3:
        return <Result videoSrc={resultVideo} />
    };
  }

  function handleNext() {
    setActiveStep(activeStep + 1);
  }
	
  function updateProgress() {
    fetch(`/api/style/status`).then((res) => {
      return res.json();
    }).then((res) => {
      setLoadingProgress(res.percentage);
      console.log(loadingTimer);
      if (res.path !== undefined) {
        clearInterval(loadingTimer);
        setStatus(0);
        setActiveStep(activeStep + 1);
        setResultVideo(res.path);
      }
    });
  }

  function handlePreview() {
    let formData = new FormData();
    console.log(files);
    console.log(modelParam);
    setStatus(1); // status = loading without progress

    let args = {
      video: "video.mp4",
      keyframes: getFramelist(),
      ...modelParam
    }

    for (const [key, value] of Object.entries(args)) {
      formData.append(key, value);
    }

    if (files.length > 0) {
      formData.append("style", files[0]);
    }

    console.log(args);
    fetch(`/api/style/image`, {
      method: 'POST',
      body: formData
    }).then((res) => {
      return res.json();
    }).then((res) => {
      console.log(res);
      setActiveStep(activeStep + 1);
      setStatus(0);
      setPreviewImages(res.path);
    });
  }

  function handleBack() {
    setActiveStep(activeStep - 1);
  }

  async function handleGenerate() {
    fetch(`/api/style/video`);
    await sleep(2000);
    let intervalID = setInterval(updateProgress, 1000);
    console.log(intervalID);
    //setLoadingTimer({intervalID: intervalID});
    loadingTimer = intervalID;
    setLoadingProgress(0);
    setStatus(2); // status = loading with progress
  }

  function getButtons() {
    if (status != 0) return null;
    if (activeStep == 1) {
      return (
        <Box style={{ position: "absolute", bottom: 0, right: 0 }} sx={{ pt: 5, pb: 5, pr: 5 }}>
          <Button onClick={handleBack}>Back</Button>
          <Button onClick={handlePreview}>Preview</Button>
        </Box>
      );
    }
    else if (activeStep == 2) {
      return (
        <Box style={{ position: "absolute", bottom: 0, right: 0 }} sx={{ pt: 5, pb: 5, pr: 5 }}>
          <Button onClick={handleBack}>Back</Button>
          <Button onClick={handleGenerate}>Generate</Button>
        </Box>
      );
    }
    else if (activeStep > 0) {
      return (
        <Box style={{ position: "absolute", bottom: 0, right: 0 }} sx={{ pt: 5, pb: 5, pr: 5 }}>
          <Button onClick={handleBack}>Back</Button>
          <Button onClick={handleNext}>Next</Button>
        </Box>
      );
    } else {
      return (
        <Box style={{ position: "absolute", bottom: 0, right: 0 }} sx={{ pt: 5, pb: 5, pr: 5 }}>
          <Button onClick={handleNext}>Next</Button>
        </Box>
      );
    }
  }

  return (
    <div>
      <Container maxWidth="xl" sx={{ mb: 4 }}>
        <Container maxWidth="sm">
          <Stepper activeStep={activeStep} sx={{ pt: 3, pb: 1, my: { xs: 3, md: 6 } }}>
            {steps.map((label, index) => {
              const stepProps = {};
              const labelProps = {};
              return (
                <Step key={label} {...stepProps}>
                  <StepLabel {...labelProps}>{label}</StepLabel>
                </Step>
              );
            })}
          </Stepper>
          <React.Fragment>
            {getStepContent(activeStep)}
          </React.Fragment>
          <Box fullWidth>
            {getButtons()}
          </Box>
        </Container>
      </Container>
    </div>
  );
}

export default App;
