import React from 'react';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import Divider from '@mui/material/Divider';
import Box from '@mui/material/Box';
import FSTParam from "./models/FST.js"
import CASTParam from './models/CAST.js';

import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import "./slick-custom.css"

function ParamForm(props) {
  function getModelParamForm(model) {
    switch (props.modelParam.model) {
      case "FST":
        return <FSTParam modelParam={props.modelParam} setModelParam={props.setModelParam}/>;
      case "CAST":
        return <CASTParam 
          modelParam={props.modelParam} setModelParam={props.setModelParam}
          files={props.files} setFiles={props.setFiles}
        />;
    }
  }

  function handleModelSwitch(event) {
    console.log(event.target.value);
    if (event.target.value === "FST") {
      props.setModelParam({
        model: "FST",
        style: "udnie"
      });
    } else {
      props.setModelParam({
        model: "CAST",
        preserve_content: true,
        preserve_style: false,
      });
      props.setFiles([]);
    }
  }

  return (
    <Box>
      <Box>
        <FormControl fullWidth>
          <InputLabel id="model-select-label">Model</InputLabel>
          <Select
            labelId="model-select-label"
            id="model-select"
            label="model"
            onChange={handleModelSwitch}
            value={props.modelParam.model}
          >
            <MenuItem value="FST">FST</MenuItem>
            <MenuItem value="CAST">CAST</MenuItem>
          </Select>
        </FormControl>
      </Box>
      <br/>
      <Divider/>
      <br/>
      {getModelParamForm()}
    </Box>
  );
}

export default ParamForm;
