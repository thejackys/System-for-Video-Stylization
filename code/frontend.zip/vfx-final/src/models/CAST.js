import React from 'react';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import Box from '@mui/material/Box';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import Grid from '@mui/material/Grid';
import FormControlLabel from '@mui/material/FormControlLabel';
import Switch from '@mui/material/Switch';
import FileUpload from 'react-material-file-upload';

function CASTParam(props) {
  function getSwitch(checked) {
    if (checked) {
      return (<Switch defaultChecked />);
    }
    return (<Switch />);
  }

  function onPreserveContentChange () {
    props.setModelParam({
      ...props.modelParam,
      preserve_content: !props.modelParam.preserve_content
    })
  }

  function onPreserveStyleChange () {
    props.setModelParam({
      ...props.modelParam,
      preserve_style: !props.modelParam.preserve_style
    })
  }

  return (
    <Grid container spacing={2}>
      <Grid item xs={12} >
        <FileUpload value={props.files} onChange={props.setFiles} />
      </Grid>
      <Grid item xs={6}>
        <FormControlLabel  
          control={getSwitch(props.modelParam.preserve_content)}
          label="Preserve Content" 
          onChange={onPreserveContentChange}
          />
      </Grid>
      <Grid item xs={6}>
        <FormControlLabel 
          control={getSwitch(props.modelParam.preserve_style)}
          label="Preserve Style"
          onChange={onPreserveStyleChange}
          />
      </Grid>
    </Grid>
  );
}

export default CASTParam;
