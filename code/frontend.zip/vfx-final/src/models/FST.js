
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import Grid from '@mui/material/Grid';



function FSTParam(props) {
  function onStyleChange(event) {
    props.setModelParam({
      ...props.modelParam,
      style: event.target.value,
    });
  }
  return (
    <Grid container spacing={2}>
    <Grid item xs={12}>
      <FormControl fullWidth>
        <InputLabel id="style">Style</InputLabel>
        <Select
          labelId="style"
          id="style"
          label="style"
	  onChange={onStyleChange}
          defaultValue={props.modelParam.style}
        >
          <MenuItem value="la_muse">la_muse</MenuItem>
          <MenuItem value="rain_princess">rain_princess</MenuItem>
          <MenuItem value="scream">Scream</MenuItem>
          <MenuItem value="udnie">Udnie</MenuItem>
          <MenuItem value="wave">Wave</MenuItem>
          <MenuItem value="wreck">Wreck</MenuItem>
        </Select>
      </FormControl>
    </Grid>
    </Grid>
  );
}

export default FSTParam;
